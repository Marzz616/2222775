<?php require_once APPROOT . '/views/includes/header.php'; ?>

<h3><?php echo $data['title']; ?></h3>

<a href="<?= URLROOT; ?>/instructeurs/index">Instructeurs</a> |
<a href="<?= URLROOT; ?>/Countries/index">Landen van de Wereld</a> |



<?php require_once APPROOT . '/views/includes/footer.php'; ?>