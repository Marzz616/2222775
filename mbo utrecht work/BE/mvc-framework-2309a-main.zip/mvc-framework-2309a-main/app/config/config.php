<?php
/**
 * De database verbindingsgegevens
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'mvcframework-2309a');
define('DB_USER', 'root');
define('DB_PASS', '');


/**
 * De naam van de virtualhost
 */
define('URLROOT', 'http://www.mvc-framework-2309a.org');


/**
 * Het pad naar de folder app
 */
define('APPROOT', dirname(dirname(__FILE__)));

