<?php
   /**
    * We sluiten het bestand require.php in
    */ 
   require_once '../app/require.php';